# Gatherly — Event Management System

A polished, responsive frontend prototype for a campus event-management application built with HTML, CSS and vanilla JavaScript.

## Features
- Dashboard with featured events and category filters
- Explore page with keyword, category and date filtering
- Event details modal with date, venue, host and capacity information
- Register/unregister-style state (registration is saved locally)
- Save events for later
- My Registrations page with summary counts
- Responsive desktop/mobile layout
- Local persistence using `localStorage`

## Run it
1. Extract the ZIP.
2. Open `index.html` in a browser. For the most reliable experience, use VS Code with the Live Server extension.
3. No package installation or backend is required.

## Important note
This is a frontend demonstration. Event data is sample data, and registrations are stored only in the current browser using `localStorage`. For a production application, connect a backend API and database, add authentication, and validate event capacity on the server.
