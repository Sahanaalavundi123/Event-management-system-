const events = [
 {id:1,title:"Future Forward: AI & Innovation Summit",category:"Technology",date:"2026-10-27",time:"10:00 AM – 1:00 PM",venue:"Innovation Hub, Block C",host:"Tech Society",emoji:"🤖",theme:"linear-gradient(135deg,#d8d2ff,#b5a7f7)",description:"Explore the ideas shaping tomorrow with student innovators, practical demos and conversations on responsible AI.",attendees:128,capacity:180,price:"Free",hostInitials:"TS"},
 {id:2,title:"Canvas & Coffee: Creative Meetup",category:"Arts & Culture",date:"2026-10-29",time:"2:00 PM – 4:00 PM",venue:"The Courtyard Café",host:"Art Collective",emoji:"🎨",theme:"linear-gradient(135deg,#ffdfc9,#f5b9ad)",description:"Take a break from your routine and spend an easy afternoon sketching, painting and meeting fellow creatives. All materials included.",attendees:46,capacity:60,price:"Free",hostInitials:"AC"},
 {id:3,title:"Career Launchpad: Resume & LinkedIn",category:"Career",date:"2026-11-02",time:"11:00 AM – 12:30 PM",venue:"Seminar Hall 2",host:"Career Development Cell",emoji:"🚀",theme:"linear-gradient(135deg,#ccefe3,#8ed9c0)",description:"Make your first impression count. Get practical tips for resumes, LinkedIn profiles and interview preparation from career mentors.",attendees:93,capacity:120,price:"Free",hostInitials:"CD"},
 {id:4,title:"Campus Beats: Open-Air Music Night",category:"Social",date:"2026-11-05",time:"5:30 PM – 8:30 PM",venue:"Main Quadrangle",host:"Student Council",emoji:"🎸",theme:"linear-gradient(135deg,#ffd7e4,#f7a9c6)",description:"Bring your friends, discover campus performers and enjoy a feel-good evening of live music under the open sky.",attendees:210,capacity:300,price:"Free",hostInitials:"SC"},
 {id:5,title:"Buildathon: Make Something Useful",category:"Technology",date:"2026-11-08",time:"9:00 AM – 6:00 PM",venue:"Computer Lab, Block A",host:"Developer Community",emoji:"💻",theme:"linear-gradient(135deg,#d4e4ff,#a7c4f8)",description:"Team up, build a prototype and learn by doing. Open to beginners and experienced makers alike. Bring your curiosity.",attendees:76,capacity:100,price:"Free",hostInitials:"DC"},
 {id:6,title:"Mindful Mornings: Yoga & Reset",category:"Wellness",date:"2026-11-10",time:"7:30 AM – 8:30 AM",venue:"Sports Centre Lawn",host:"Wellness Club",emoji:"🌿",theme:"linear-gradient(135deg,#e4efc8,#b8d89c)",description:"Start your day with gentle movement, breathing exercises and a calm moment before classes begin. Please bring a mat.",attendees:34,capacity:50,price:"Free",hostInitials:"WC"},
 {id:7,title:"Design Thinking Workshop",category:"Career",date:"2026-11-12",time:"1:00 PM – 3:00 PM",venue:"Design Studio, Block D",host:"Innovation Cell",emoji:"💡",theme:"linear-gradient(135deg,#ffe9ad,#ffd071)",description:"Learn how to turn real-world problems into thoughtful solutions through empathy mapping, ideation and quick prototyping.",attendees:58,capacity:80,price:"Free",hostInitials:"IC"},
 {id:8,title:"Food Fest: Flavours of Campus",category:"Social",date:"2026-11-15",time:"12:00 PM – 4:00 PM",venue:"Central Lawn",host:"Cultural Committee",emoji:"🍜",theme:"linear-gradient(135deg,#ffdfc0,#f9b27b)",description:"Taste a little bit of everything, support student-run stalls and enjoy an afternoon full of food, music and campus spirit.",attendees:265,capacity:350,price:"₹50",hostInitials:"CC"},
 {id:9,title:"Stories on Stage: Open Mic",category:"Arts & Culture",date:"2026-11-18",time:"4:00 PM – 6:00 PM",venue:"Amphitheatre",host:"Literary Club",emoji:"🎤",theme:"linear-gradient(135deg,#e4d5ff,#c4a6f5)",description:"Poetry, music, storytelling or stand-up—bring something to share or simply come cheer on your classmates.",attendees:61,capacity:90,price:"Free",hostInitials:"LC"}
];

let activeCategory = "All";
let currentEventId = null;
let toastTimer;
const registrations = new Set(JSON.parse(localStorage.getItem("gatherlyRegistrations") || "[]"));
const savedEvents = new Set(JSON.parse(localStorage.getItem("gatherlySaved") || "[]"));
const $ = (id) => document.getElementById(id);

function formatDate(dateStr, style = "long") {
  const d = new Date(dateStr + "T12:00:00");
  if (style === "short") return {day:d.toLocaleDateString("en-US",{day:"2-digit"}),month:d.toLocaleDateString("en-US",{month:"short"}).toUpperCase()};
  return d.toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric",year:"numeric"});
}
function escapeHTML(s) { return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function toast(message) {
  $("toast").textContent = message; $("toast").classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => $("toast").classList.remove("show"), 2600);
}
function persist() {
  localStorage.setItem("gatherlyRegistrations", JSON.stringify([...registrations]));
  localStorage.setItem("gatherlySaved", JSON.stringify([...savedEvents]));
  updateCounts();
}
function updateCounts() {
  $("registrationCount").textContent = registrations.size;
  $("myTotal").textContent = registrations.size;
  const upcoming = [...registrations].filter(id => new Date(events.find(e=>e.id===id)?.date) >= new Date("2026-10-22")).length;
  $("myUpcoming").textContent = upcoming;
}
function cardMarkup(e) {
  const date = formatDate(e.date,"short");
  const saved = savedEvents.has(e.id);
  return `<article class="event-card">
    <div class="event-cover" style="background:${e.theme}">
      <div class="cover-date"><b>${date.day}</b><small>${date.month}</small></div>
      <span class="cover-emoji">${e.emoji}</span>
      <button class="bookmark-btn ${saved?"saved":""}" data-save="${e.id}" aria-label="${saved?"Remove saved event":"Save event"}">${saved?"♥":"♡"}</button>
    </div>
    <div class="event-card-body">
      <div class="event-category">${escapeHTML(e.category)}</div>
      <h3>${escapeHTML(e.title)}</h3>
      <p class="card-description">${escapeHTML(e.description)}</p>
      <div class="card-info"><span>◷</span><span>${formatDate(e.date)} · ${escapeHTML(e.time)}</span></div>
      <div class="card-info"><span>⌖</span><span class="truncate">${escapeHTML(e.venue)}</span></div>
      <div class="card-footer"><div class="attendees"><span class="mini-avatars"><i>${e.hostInitials[0]}</i><i>✦</i><i>+</i></span>${e.attendees}+ attending</div><button class="card-open" data-open="${e.id}">Details <span>→</span></button></div>
    </div>
  </article>`;
}
function renderFeatured() {
  let list = events.filter(e => activeCategory === "All" || e.category === activeCategory);
  const q = $("globalSearch").value.trim().toLowerCase();
  if (q) list = list.filter(e => `${e.title} ${e.category} ${e.venue} ${e.host}`.toLowerCase().includes(q));
  if ($("sortSelect").value === "popular") list.sort((a,b)=>b.attendees-a.attendees);
  else list.sort((a,b)=>a.date.localeCompare(b.date));
  $("featuredEvents").innerHTML = list.slice(0,6).map(cardMarkup).join("");
  $("allCount").textContent = events.length;
  $("emptyState").classList.toggle("hidden",list.length>0);
}
function renderAll() {
  let list = [...events];
  const q = $("eventSearch").value.trim().toLowerCase();
  const category = $("categorySelect").value;
  const dateFilter = $("dateSelect").value;
  if (q) list = list.filter(e => `${e.title} ${e.category} ${e.venue} ${e.host} ${e.description}`.toLowerCase().includes(q));
  if (category !== "All") list = list.filter(e=>e.category===category);
  const now = new Date("2026-10-22T00:00:00");
  if (dateFilter === "week") list = list.filter(e => {const d=new Date(e.date+"T12:00:00");return d>=now && d<=new Date("2026-10-29T23:59:59");});
  if (dateFilter === "month") list = list.filter(e => new Date(e.date+"T12:00:00").getMonth()===now.getMonth());
  list.sort((a,b)=>a.date.localeCompare(b.date));
  $("allEvents").innerHTML = list.map(cardMarkup).join("");
  $("resultCount").textContent = `${list.length} event${list.length===1?"":"s"}`;
  $("exploreEmpty").classList.toggle("hidden",list.length>0);
}
function renderRegistrations() {
  const list = events.filter(e=>registrations.has(e.id)).sort((a,b)=>a.date.localeCompare(b.date));
  $("registeredList").innerHTML = list.map(e=>`<article class="registered-item">
    <div class="registered-art" style="background:${e.theme}">${e.emoji}</div>
    <div class="registered-info"><div class="event-category">${escapeHTML(e.category)}</div><h3>${escapeHTML(e.title)}</h3><p>${formatDate(e.date)} · ${escapeHTML(e.time)} · ${escapeHTML(e.venue)}</p></div>
    <span class="registered-status">✓ Registered</span><button class="card-open" data-open="${e.id}">Details →</button>
    </article>`).join("");
  $("registrationsEmpty").classList.toggle("hidden",list.length>0);
  updateCounts();
}
function switchView(name) {
  document.querySelectorAll(".view").forEach(v=>v.classList.remove("active"));
  document.querySelectorAll(".nav-item").forEach(v=>v.classList.toggle("active",v.dataset.view===name));
  const ids = {dashboard:"dashboardView",events:"eventsView","my-events":"myEventsView"};
  $(ids[name]).classList.add("active");
  $("pageCrumb").textContent = ({dashboard:"Overview",events:"Explore events","my-events":"My registrations"})[name];
  $("sidebar").classList.remove("open");
  if(name==="events") renderAll();
  if(name==="my-events") renderRegistrations();
}
function openEvent(id) {
  const e=events.find(e=>e.id===Number(id)); if(!e)return;
  currentEventId=e.id;
  $("modalVisual").style.background=e.theme;
  $("modalEmoji").textContent=e.emoji; $("modalCategory").textContent=e.category;
  $("modalMeta").textContent=`${e.price} event  ·  ${e.attendees} people interested`;
  $("modalTitle").textContent=e.title; $("modalDescription").textContent=e.description;
  $("modalDate").textContent=`${formatDate(e.date)} · ${e.time}`;
  $("modalVenue").textContent=e.venue; $("modalHost").textContent=e.host;
  const remaining=Math.max(0,e.capacity-e.attendees);
  $("modalSpots").textContent=remaining>0?`${remaining} spots left`:"Waitlist available";
  $("spotsFill").style.width=`${Math.min(100,e.attendees/e.capacity*100)}%`;
  const registered=registrations.has(e.id);
  $("registerBtn").innerHTML=registered?'✓ You’re registered <span>✓</span>':`Register for ${e.price==="Free"?"free":e.price} <span>→</span>`;
  $("registerBtn").disabled=registered;
  $("registerBtn").style.opacity=registered?".7":"1";
  $("eventModal").classList.remove("hidden");
  document.body.style.overflow="hidden";
}
function closeModal(){ $("eventModal").classList.add("hidden");document.body.style.overflow=""; }
function toggleSave(id) {
  id=Number(id);
  if(savedEvents.has(id)){savedEvents.delete(id);toast("Removed from saved events");}
  else {savedEvents.add(id);toast("Event saved for later");}
  persist();renderFeatured();renderAll();
}
document.addEventListener("click",e=>{
  const open=e.target.closest("[data-open]"); if(open){openEvent(open.dataset.open);return;}
  const save=e.target.closest("[data-save]"); if(save){e.stopPropagation();toggleSave(save.dataset.save);return;}
  const nav=e.target.closest("[data-view]"); if(nav){switchView(nav.dataset.view);return;}
  const cat=e.target.closest("[data-category]"); if(cat){activeCategory=cat.dataset.category;document.querySelectorAll("#categoryFilters .chip").forEach(c=>c.classList.toggle("active",c===cat));renderFeatured();}
});
$("browseBtn").onclick=$("heroExplore").onclick=$("viewAllBtn").onclick=()=>switchView("events");
$("discoverBtn").onclick=()=>switchView("events");
$("sortSelect").onchange=renderFeatured;
$("globalSearch").oninput=()=>{if($("globalSearch").value.trim())switchView("dashboard");renderFeatured();};
$("eventSearch").oninput=renderAll;
$("categorySelect").onchange=renderAll;
$("dateSelect").onchange=renderAll;
$("closeModal").onclick=closeModal;
$("eventModal").addEventListener("click",e=>{if(e.target===$("eventModal"))closeModal();});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal();});
$("registerBtn").onclick=()=>{
  if(!currentEventId||registrations.has(currentEventId))return;
  registrations.add(currentEventId);persist();renderRegistrations();
  const event=events.find(e=>e.id===currentEventId);
  toast(`You’re registered for ${event.title}!`);
  openEvent(currentEventId);
};
$("menuBtn").onclick=()=>$("sidebar").classList.toggle("open");
$("helpBtn").onclick=()=>toast("Support: contact your campus event coordinator.");
$("notificationBtn").onclick=()=>toast("You’re all caught up!");
$("resetFilters").onclick=()=>{activeCategory="All";$("globalSearch").value="";document.querySelectorAll("#categoryFilters .chip").forEach(c=>c.classList.toggle("active",c.dataset.category==="All"));renderFeatured();};
renderFeatured();renderAll();renderRegistrations();
