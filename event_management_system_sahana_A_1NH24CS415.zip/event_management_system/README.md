# EVENT MANAGEMENT SYSTEM
## Project Portfolio and Source Code

**Student Name:** Sahana A  
**USN:** 1NH24CS415  
**Project Title:** Event Management System  
**Course/Subject:** Full Stack Technologies  
**Frontend:** HTML5, CSS3, JavaScript  
**Project Type:** Responsive web application prototype

---

## 1. Project Overview

The Event Management System is a web application prototype designed to help students discover campus events, view event information, register for events, and keep track of their registrations. It provides a centralized and easy-to-use interface for event discovery and participation.

The interface is branded **Gatherly**. The application uses sample campus-event data and browser local storage to demonstrate the main user journey.

## 2. Problem Statement

Campus event information can be shared across different notices, messages, and social platforms. This can make it difficult for students to find event details, compare upcoming activities, and remember which events they have registered for. A centralized event-management interface can organize event information and make event discovery and registration easier.

## 3. Project Objectives

- Build a clean, responsive web interface for campus event discovery.
- Display event names, categories, dates, times, venues, hosts, and descriptions.
- Provide keyword search and category/date filters.
- Allow users to open a detailed view of an event.
- Demonstrate event registration and saved-event functionality.
- Display registered events in a dedicated page.
- Preserve demo registrations and bookmarks between browser visits using local storage.
- Organize the code into HTML, CSS, and JavaScript files for easy maintenance.

## 4. Scope of the Project

The current version is a frontend prototype for demonstrating the user interface and core interaction flow. It uses sample data bundled in JavaScript. It does not currently provide a real account system, server-side event management, or a shared database. Those can be added as future enhancements.

## 5. Technologies and Tools Used

| Technology / Tool | Purpose |
|---|---|
| HTML5 | Structure of the pages and interface |
| CSS3 | Layout, colours, responsive design, and styling |
| JavaScript (ES6) | Event cards, search, filters, modal, registration and bookmarks |
| Browser localStorage | Saves registrations and bookmarks in the current browser |
| Visual Studio Code | Recommended code editor |
| Web browser | Running and testing the prototype |
| Git and GitHub | Recommended for version control and source-code hosting |

## 6. System Overview

The application includes three main views:

1. **Overview:** Welcome section, featured events, category chips, and event cards.
2. **Explore Events:** Searchable and filterable list of campus events.
3. **My Registrations:** Registered event list and summary counts.

Each event includes a title, category, date, time, venue, host, description, attendee count, capacity, price label, and visual theme. Selecting an event opens a details dialog. Users can register for events and save events for later.

## 7. Main Features

### 7.1 Dashboard
Shows a welcome banner and a selection of upcoming events.

### 7.2 Search and Filtering
Search events by title, venue, category, host, or description. Filter by category and date range.

### 7.3 Event Details
Shows event information such as date, time, location, host, description, and remaining-space estimate.

### 7.4 Event Registration
Allows a user to register for an event. The registration state is saved in localStorage and appears under My Registrations.

### 7.5 Saved Events
Users can bookmark and unbookmark event cards. Saved state is stored locally in the browser.

### 7.6 Responsive Layout
The layout adapts for desktop, tablet, and mobile screens, including a collapsible navigation menu on smaller screens.

## 8. Project Folder Structure

```text
event_management_system/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── app.js
└── README.md
```

- `index.html` contains the page layout, navigation, event views, and event-details modal.
- `css/style.css` contains the visual design, cards, layout, modal, responsive breakpoints, and mobile styles.
- `js/app.js` contains sample event data and the search, filtering, registration, bookmarking, and navigation logic.
- `README.md` explains the project, setup, features, limitations, and future improvements.

## 9. How to Set Up and Run

1. Download and extract the source-code ZIP file.
2. Open the extracted folder in Visual Studio Code.
3. Open `index.html` in a browser, or use the **Live Server** extension in VS Code.
4. Browse the events from the Overview page or Explore Events page.
5. Select **Details** to view event information.
6. Select **Register for free** to register for a sample event.
7. Open **My registrations** to see registered events.
8. Use the heart icon on an event card to save or unsave it.

No package installation or backend setup is needed for this prototype.

## 10. Implementation Methodology

1. **Requirement identification:** Identify the main student actions: explore, search, view details, register, and save.
2. **Interface design:** Create a dashboard layout with navigation, filters, event cards, and a details modal.
3. **Frontend development:** Use HTML for structure and CSS for the responsive visual design.
4. **Interaction development:** Use JavaScript to render event data, filter results, switch views, and manage the modal.
5. **Browser persistence:** Store registration IDs and saved-event IDs in localStorage.
6. **Testing:** Check the navigation, event search, filters, event details, registration flow, saved events, and mobile layout in a browser.

## 11. Testing Checklist

| Test case | Expected result |
|---|---|
| Open `index.html` | Overview page is displayed |
| Select Explore Events | All sample events are listed |
| Search by event title | Matching events are displayed |
| Select a category | Events are filtered by that category |
| Open event details | Correct details are displayed in the modal |
| Register for an event | Registration state changes and a confirmation message appears |
| Open My Registrations | Registered events are displayed |
| Save an event | Heart icon indicates saved state |
| Refresh the browser | Local registrations and saved events remain |
| Use on a narrow screen | Layout adapts for mobile use |

These are suggested manual checks for the prototype; they should be performed in the target browser before claiming formal test results.

## 12. Challenges and Limitations

- Keeping event cards, search results, registration status, and bookmark status synchronized.
- Making the layout responsive for different screen sizes.
- Persisting user actions between browser sessions without a backend.
- Sample event data is fixed in the JavaScript file.
- Registration information is stored only in the current browser and is not shared with other users or devices.
- There is no authentication, admin dashboard, backend API, or database in this version.
- Event capacity and attendee figures are demonstrational and are not verified by a server.

## 13. Future Enhancements

- Add user registration and secure login.
- Create an admin panel to create, edit, and delete events.
- Connect a backend such as Flask, Django, Node.js, or Express.
- Store events and registrations in a database such as MySQL, PostgreSQL, or SQLite.
- Add email confirmations and event reminders.
- Add QR-code tickets and check-in.
- Add real-time seat availability and server-side validation.
- Deploy the application so that it can be accessed online.

## 14. Learning Outcomes

- Practised structuring a multi-view web interface using HTML.
- Applied CSS for layout, typography, visual hierarchy, and responsive design.
- Used JavaScript event handlers, arrays, filtering, DOM updates, and modal interactions.
- Learned to use localStorage for browser-side persistence.
- Organised a small project into separate frontend files.
- Identified the difference between a frontend prototype and a full-stack production application.

## 15. Conclusion

The Event Management System demonstrates a user-friendly way for students to discover campus activities, explore event details, save events, and manage their registrations. The project combines HTML, CSS, and JavaScript to deliver a responsive interface with interactive functionality. Connecting a backend and database would be the next step toward supporting real users and shared event records.

---

**Student:** Sahana A  
**USN:** 1NH24CS415  
**Project:** Event Management System
